﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using assignment3.Models;

namespace assignment3.Controllers
{
    public class HomeController : Controller
    {

        linq2sqlDataContext ls = new linq2sqlDataContext();
        public ActionResult kfcv()
        {
            return View(ls.kfcs.ToList());
            
        }

        public ActionResult mcv()
        {
            return View(ls.MCs.ToList());
        }

        public ActionResult subwayv()
        {
            return View(ls.subways.ToList());
        }

        public ActionResult AddItem()
        {
            return View();
        }

 

        public ActionResult Display()
        {
            return View();
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult addnewkfc()
        {
            kfc k = new kfc();
            string name = Request["name"];
            int price = Convert.ToInt32(Request["price"]);
            int val = Convert.ToInt32(Request["val"]);
            k.name = name;
            k.price = price;
            k.val = 1;
            ls.kfcs.InsertOnSubmit(k);
            ls.SubmitChanges();

            return RedirectToAction("AddItem");
        }

        public ActionResult addnewmc()
        {
            MC k = new MC();
            string name = Request["name"];
            int price = Convert.ToInt32(Request["price"]);
            int val = Convert.ToInt32(Request["val"]);
            k.name = name;
            k.price = price;
            k.val = 2;
            ls.MCs.InsertOnSubmit(k);
            ls.SubmitChanges();

            return RedirectToAction("AddItem");
        }

        public ActionResult addnewsubw()
        {
            subway k = new subway();
            string name = Request["name"];
            int price = Convert.ToInt32(Request["price"]);
            int val = Convert.ToInt32(Request["val"]);
            k.name = name;
            k.price = price;
            k.val = 3;
            ls.subways.InsertOnSubmit(k);
            ls.SubmitChanges();

            return RedirectToAction("AddItem");
        }

        public ActionResult EditItem(int id)
        {
            return View(ls.kfcs.First(c => c.Id == id));
        }

        public ActionResult editk(int id)
        {
            var q = ls.kfcs.First(c => c.Id == id);
            q.name = Request["name"];
            q.price = Convert.ToInt32(Request["price"]);

            ls.SubmitChanges();

            return RedirectToAction("Index");
        }

        public ActionResult editm(int id)
        {
            var q = ls.MCs.First(c => c.Id == id);
            q.name = Request["name"];
            q.price = Convert.ToInt32(Request["price"]);

            ls.SubmitChanges();

            return RedirectToAction("Index");
        }
        public ActionResult edit2(int id)
        {
            return View(ls.MCs.First(c => c.Id == id));
        }


        public ActionResult edits(int id)
        {
            var q = ls.subways.First(c => c.Id == id);
            q.name = Request["name"];
            q.price = Convert.ToInt32(Request["price"]);

            ls.SubmitChanges();

            return RedirectToAction("Index");
        }
        public ActionResult edit3(int id)
        {
            return View(ls.subways.First(c => c.Id == id));
        }

    }
}